const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");

let camera = null;

/* -----------------------------
   Initialize MediaPipe Hands
------------------------------ */
const hands = new Hands({
  locateFile: (file) =>
    `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
});

hands.setOptions({
  maxNumHands: 2,
  modelComplexity: 1,
  minDetectionConfidence: 0.7,
  minTrackingConfidence: 0.7,
});

/* -----------------------------
   When hand results are ready
------------------------------ */
hands.onResults((results) => {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw the video frame
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

  if (results.multiHandLandmarks) {
    for (const landmarks of results.multiHandLandmarks) {
      // Draw hand connections
      drawConnectors(ctx, landmarks, HAND_CONNECTIONS, {
        color: "#00FF00",
        lineWidth: 2,
      });

      // Draw hand landmarks (21 points)
      drawLandmarks(ctx, landmarks, {
        color: "#FF0000",
        lineWidth: 1,
      });
    }
  }
});

/* -----------------------------
   Start Camera
------------------------------ */
startBtn.addEventListener("click", () => {
  camera = new Camera(video, {
    onFrame: async () => {
      await hands.send({ image: video });
    },
    width: 640,
    height: 480,
  });

  camera.start();

  // Match canvas size with video
  video.onloadedmetadata = () => {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
  };
});

/* -----------------------------
   Stop Camera
------------------------------ */
stopBtn.addEventListener("click", () => {
  if (camera) {
    camera.stop();
  }

  ctx.clearRect(0, 0, canvas.width, canvas.height);
});
