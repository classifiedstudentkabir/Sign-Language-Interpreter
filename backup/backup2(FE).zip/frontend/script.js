const videoElement = document.getElementById("video");
const canvasElement = document.getElementById("canvas");
const canvasCtx = canvasElement.getContext("2d");
const gestureText = document.getElementById("gestureText");
const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const statusEl = document.getElementById("status");

// ---------------- HELPERS ----------------
function isFingerExtended(tip, pip) {
  return tip.y < pip.y;
}

function dist(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

// ---------------- GESTURE LOGIC ----------------
function detectGesture(landmarks) {
  const wrist = landmarks[0];

  const thumbTip = landmarks[4];
  const thumbIP = landmarks[3];

  const indexTip = landmarks[8];
  const indexPIP = landmarks[6];

  const middleTip = landmarks[12];
  const middlePIP = landmarks[10];

  const ringTip = landmarks[16];
  const ringPIP = landmarks[14];

  const pinkyTip = landmarks[20];
  const pinkyPIP = landmarks[18];

  const indexUp = isFingerExtended(indexTip, indexPIP);
  const middleUp = isFingerExtended(middleTip, middlePIP);
  const ringUp = isFingerExtended(ringTip, ringPIP);
  const pinkyUp = isFingerExtended(pinkyTip, pinkyPIP);

  const thumbUp = thumbTip.y < thumbIP.y;

  // 1️⃣ STOP – open palm
  if (thumbUp && indexUp && middleUp && ringUp && pinkyUp) {
    return "STOP ✋";
  }

  // 2️⃣ YES – thumbs up (CHECK BEFORE NO)
  if (
    thumbUp &&
    !indexUp &&
    !middleUp &&
    !ringUp &&
    !pinkyUp
  ) {
    return "YES 👍";
  }

  // 3️⃣ NO – closed fist (thumb must NOT be up)
  const fingersNearWrist =
    dist(indexTip, wrist) < 0.45 &&
    dist(middleTip, wrist) < 0.45 &&
    dist(ringTip, wrist) < 0.45 &&
    dist(pinkyTip, wrist) < 0.45;

  if (
    !thumbUp &&
    !indexUp &&
    !middleUp &&
    !ringUp &&
    !pinkyUp &&
    fingersNearWrist
  ) {
    return "NO ✊";
  }

  return "Gesture: Unknown";
}

// ---------------- MEDIAPIPE CALLBACK ----------------
function onResults(results) {
  canvasCtx.save();
  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
  canvasCtx.drawImage(
    results.image,
    0,
    0,
    canvasElement.width,
    canvasElement.height
  );

  if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
    const landmarks = results.multiHandLandmarks[0];

    drawConnectors(canvasCtx, landmarks, HAND_CONNECTIONS, {
      color: "#00FF00",
      lineWidth: 2,
    });
    drawLandmarks(canvasCtx, landmarks, {
      color: "#FF0000",
      lineWidth: 1,
    });

    const gesture = detectGesture(landmarks);
    gestureText.innerText = "Gesture: " + gesture;
  } else {
    gestureText.innerText = "Gesture: None";
  }

  canvasCtx.restore();
}

// ---------------- CAMERA SETUP ----------------
let camera = null;

const hands = new Hands({
  locateFile: (file) =>
    `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
});

hands.setOptions({
  maxNumHands: 1,
  modelComplexity: 1,
  minDetectionConfidence: 0.7,
  minTrackingConfidence: 0.7,
});

hands.onResults(onResults);

startBtn.onclick = async () => {
  camera = new Camera(videoElement, {
    onFrame: async () => {
      await hands.send({ image: videoElement });
    },
    width: 640,
    height: 480,
  });
  await camera.start();
  statusEl.innerText = "Camera started";
};

stopBtn.onclick = () => {
  if (camera) camera.stop();
  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
  statusEl.innerText = "Camera stopped";
};
