export const TWO_HAND_SIGNS = [
  {
    name: "6",
    left: "FIVE",
    right: "ONE",
  },
  {
    name: "7",
    left: "FIVE",
    right: "TWO",
  },
  {
    name: "8",
    left: "FIVE",
    right: "THREE",
  },
  {
    name: "9",
    left: "FIVE",
    right: "FOUR",
  },
  {
    name: "10",
    left: "FIVE",
    right: "FIVE",
  },
];