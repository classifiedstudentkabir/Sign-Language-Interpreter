import { setupCamera } from "./camera.js";
import { detectHands } from "./handDetector.js";

const videoElement = document.getElementById("video");
const outputElement = document.getElementById("gestureText");

function onResults(results) {
  const detection = detectHands(results);

  if (detection.count === 0) {
    outputElement.innerText = "No hands detected";
    return;
  }

  if (detection.count === 1) {
    outputElement.innerText = "One hand detected";
    // Phase 2 will go here
    return;
  }

  if (detection.count === 2) {
    outputElement.innerText = "Two hands detected";
    // Phase 3 will go here
    return;
  }
}

setupCamera(videoElement, onResults);