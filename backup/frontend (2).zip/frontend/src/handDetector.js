export function detectHands(results) {
  if (!results.multiHandLandmarks) {
    return {
      count: 0,
      hands: [],
    };
  }

  const hands = results.multiHandLandmarks.map((landmarks, index) => ({
    id: index,
    landmarks,
  }));

  return {
    count: hands.length,
    hands,
  };
}