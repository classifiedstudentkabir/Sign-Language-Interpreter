// ================== ELEMENTS ==================
const videoElement = document.getElementById("video");
const canvasElement = document.getElementById("canvas");
const canvasCtx = canvasElement.getContext("2d");
const gestureText = document.getElementById("gestureText");

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");

// ================== STATE ==================
let currentGesture = "Unknown";
let lastStableGesture = "";
let lastSpokenGesture = "";

let gestureCounter = 0;
const STABLE_FRAMES = 5;

let camera = null;
let mediaStream = null;
let isCameraRunning = false;

// ================== SPEECH ==================
const synth = window.speechSynthesis;

function speak(text) {
  if (!synth || synth.speaking) return;

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-US";
  synth.speak(utterance);
}

// ================== HELPERS ==================
function isFingerExtended(tip, pip) {
  return tip.y < pip.y;
}

// ================== GESTURE DETECTION ==================
function detectGesture(landmarks) {
  const thumbTip = landmarks[4];
  const indexTip = landmarks[8];
  const indexPip = landmarks[6];
  const middleTip = landmarks[12];
  const middlePip = landmarks[10];
  const ringTip = landmarks[16];
  const ringPip = landmarks[14];
  const pinkyTip = landmarks[20];
  const pinkyPip = landmarks[18];

  const index = isFingerExtended(indexTip, indexPip);
  const middle = isFingerExtended(middleTip, middlePip);
  const ring = isFingerExtended(ringTip, ringPip);
  const pinky = isFingerExtended(pinkyTip, pinkyPip);

  if (index && middle && ring && pinky) return "STOP";
  if (
    thumbTip.y < landmarks[3].y &&
    !index && !middle && !ring && !pinky
  )
    return "YES";
  if (!index && !middle && !ring && !pinky) return "NO";

  return "Unknown";
}

// ================== STABILITY + SPEECH ==================
function handleGesture(newGesture) {
  if (newGesture === currentGesture) {
    gestureCounter++;
  } else {
    currentGesture = newGesture;
    gestureCounter = 1;
  }

  if (gestureCounter === STABLE_FRAMES && newGesture !== lastStableGesture) {
    lastStableGesture = newGesture;
    gestureText.textContent = `Detected Sign: ${newGesture}`;

    if (newGesture !== "Unknown" && newGesture !== lastSpokenGesture) {
      speak(newGesture);
      lastSpokenGesture = newGesture;
    }
  }
}

// ================== MEDIAPIPE ==================
const hands = new Hands({
  locateFile: (file) =>
    `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
});

hands.setOptions({
  maxNumHands: 1,
  modelComplexity: 1,
  minDetectionConfidence: 0.7,
  minTrackingConfidence: 0.7,
});

hands.onResults((results) => {
  if (!isCameraRunning) return;

  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
  canvasCtx.drawImage(
    results.image,
    0,
    0,
    canvasElement.width,
    canvasElement.height
  );

  if (results.multiHandLandmarks) {
    for (const landmarks of results.multiHandLandmarks) {
      drawConnectors(canvasCtx, landmarks, HAND_CONNECTIONS);
      drawLandmarks(canvasCtx, landmarks);

      const gesture = detectGesture(landmarks);
      handleGesture(gesture);
    }
  }
});

// ================== START CAMERA ==================
startBtn.addEventListener("click", async () => {
  if (isCameraRunning) return;

  mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
  videoElement.srcObject = mediaStream;

  camera = new Camera(videoElement, {
    onFrame: async () => {
      if (isCameraRunning) {
        await hands.send({ image: videoElement });
      }
    },
    width: 640,
    height: 480,
  });

  isCameraRunning = true;
  camera.start();
});

// ================== STOP CAMERA (FIXED) ==================
stopBtn.addEventListener("click", () => {
  if (!isCameraRunning) return;

  // 🛑 Stop MediaPipe camera
  if (camera) {
    camera.stop();
    camera = null;
  }

  // 🛑 Stop browser webcam
  if (mediaStream) {
    mediaStream.getTracks().forEach((track) => track.stop());
    mediaStream = null;
  }

  videoElement.srcObject = null;
  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

  // 🔄 Reset states
  isCameraRunning = false;
  currentGesture = "Unknown";
  lastStableGesture = "";
  lastSpokenGesture = "";
  gestureCounter = 0;

  gestureText.textContent = "Detected Sign: —";
});
