// ================== ELEMENTS ==================
const videoElement = document.getElementById("video");
const canvasElement = document.getElementById("canvas");
const canvasCtx = canvasElement.getContext("2d");
const gestureText = document.getElementById("gestureText");

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");

const speechText = document.getElementById("speechText");
const startListenBtn = document.getElementById("startListen");
const stopListenBtn = document.getElementById("stopListen");

// ================== STATE ==================
let isCameraRunning = false;
let camera = null;
let mediaStream = null;

let recognition = null;
let isListening = false;

// Gesture stability
let lastGesture = "";
let stableGesture = "";
let sameGestureCount = 0;
const STABLE_FRAMES = 7;

// ================== MEDIAPIPE HANDS ==================
const hands = new Hands({
  locateFile: (file) =>
    `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
});

hands.setOptions({
  maxNumHands: 2,
  modelComplexity: 1,
  minDetectionConfidence: 0.7,
  minTrackingConfidence: 0.7,
});

// ================== HELPER FUNCTIONS ==================

// Check if a finger is extended
function isFingerUp(landmarks, tip, pip) {
  return landmarks[tip].y < landmarks[pip].y;
}

// Detect gesture from landmarks
function detectGesture(landmarks) {
  const indexUp = isFingerUp(landmarks, 8, 6);
  const middleUp = isFingerUp(landmarks, 12, 10);
  const ringUp = isFingerUp(landmarks, 16, 14);
  const pinkyUp = isFingerUp(landmarks, 20, 18);
  const thumbUp = landmarks[4].x < landmarks[3].x;

  // STOP → Open palm
  if (indexUp && middleUp && ringUp && pinkyUp && thumbUp) {
    return "STOP";
  }

  // NO → Index finger only (give priority)
if (indexUp && !middleUp && !ringUp && !pinkyUp) {
  return "NO";
}

// YES → Strong fist (all fingers clearly down)
if (
  !indexUp &&
  !middleUp &&
  !ringUp &&
  !pinkyUp &&
  landmarks[8].y > landmarks[6].y + 0.02
) {
  return "YES";
}


  return "UNKNOWN";
}

// Stabilize gesture (avoid flickering)
function getStableGesture(current) {
  if (current === lastGesture) {
    sameGestureCount++;
  } else {
    sameGestureCount = 0;
    lastGesture = current;
  }

  if (sameGestureCount >= STABLE_FRAMES) {
    stableGesture = current;
  }

  return stableGesture;
}

// ================== RESULTS CALLBACK ==================
hands.onResults((results) => {
  if (!isCameraRunning) return;

  // Resize canvas correctly
  canvasElement.width = videoElement.videoWidth;
  canvasElement.height = videoElement.videoHeight;

  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
  const handCount = results.multiHandLandmarks?.length || 0;
  console.log("Hands detected:", handCount);


  // Draw video frame
  canvasCtx.drawImage(
    results.image,
    0,
    0,
    canvasElement.width,
    canvasElement.height
  );

  if (results.multiHandLandmarks?.length) {
    const landmarks = results.multiHandLandmarks[0];

    // ✅ DRAW LANDMARKS + CONNECTIONS
    drawConnectors(canvasCtx, landmarks, HAND_CONNECTIONS, {
      color: "#00FF00",
      lineWidth: 3,
    });

    drawLandmarks(canvasCtx, landmarks, {
      color: "#FF0000",
      lineWidth: 2,
      radius: 4,
    });

    // Detect & stabilize gesture
    const rawGesture = detectGesture(landmarks);
    const finalGesture = getStableGesture(rawGesture);

    gestureText.textContent = `Gesture: ${finalGesture || "Detecting..."}`;
    gestureText.className = "";

    if (finalGesture === "YES") gestureText.classList.add("gesture-YES");
    if (finalGesture === "NO") gestureText.classList.add("gesture-NO");
    if (finalGesture === "STOP") gestureText.classList.add("gesture-STOP");

  } else {
    gestureText.textContent = "Gesture: None";
    lastGesture = "";
    sameGestureCount = 0;
    stableGesture = "";
  }
});

// ================== CAMERA CONTROL ==================
startBtn.addEventListener("click", async () => {
  if (isCameraRunning) return;

  mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
  videoElement.srcObject = mediaStream;

  camera = new Camera(videoElement, {
    onFrame: async () => {
      if (isCameraRunning) {
        await hands.send({ image: videoElement });
      }
    },
    width: 640,
    height: 480,
  });

  isCameraRunning = true;
  camera.start();
});

stopBtn.addEventListener("click", () => {
  if (!isCameraRunning) return;

  if (camera) {
    camera.stop();
    camera = null;
  }

  if (mediaStream) {
    mediaStream.getTracks().forEach((t) => t.stop());
    mediaStream = null;
  }

  videoElement.srcObject = null;
  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

  isCameraRunning = false;
  gestureText.textContent = "Gesture: —";
});

// ================== SPEECH TO TEXT (UNCHANGED) ==================
const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition;

if (!SpeechRecognition) {
  speechText.textContent = "Speech Recognition not supported";
}

startListenBtn.addEventListener("click", () => {
  if (!SpeechRecognition || isListening) return;

  recognition = new SpeechRecognition();
  recognition.lang = "en-US";
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onstart = () => {
    speechText.textContent = "Listening...";
  };

  recognition.onresult = (event) => {
    speechText.textContent = event.results[0][0].transcript;
  };

  recognition.onend = () => {
    isListening = false;
  };

  isListening = true;
  recognition.start();
});

stopListenBtn.addEventListener("click", () => {
  if (recognition && isListening) {
    recognition.stop();
    isListening = false;
    speechText.textContent = "Stopped listening";
  }
});
