// ================== ELEMENTS ==================
const videoElement = document.getElementById("video");
const canvasElement = document.getElementById("canvas");
const canvasCtx = canvasElement.getContext("2d");
const gestureText = document.getElementById("gestureText");

// ================== STATE ==================
let currentGesture = "Unknown";
let lastStableGesture = "";
let lastSpokenGesture = "";

let gestureCounter = 0;
const STABLE_FRAMES = 5; // 🔒 gesture must be same for 5 frames

// ================== SPEECH ==================
const synth = window.speechSynthesis;

function speak(text) {
  if (!synth || synth.speaking) return;

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-US";
  utterance.rate = 1;
  utterance.pitch = 1;

  synth.speak(utterance);
}

// ================== HELPERS ==================
function isFingerExtended(tip, pip) {
  return tip.y < pip.y;
}

// ================== GESTURE DETECTION ==================
function detectGesture(landmarks) {
  const thumbTip = landmarks[4];
  const indexTip = landmarks[8];
  const indexPip = landmarks[6];
  const middleTip = landmarks[12];
  const middlePip = landmarks[10];
  const ringTip = landmarks[16];
  const ringPip = landmarks[14];
  const pinkyTip = landmarks[20];
  const pinkyPip = landmarks[18];

  const index = isFingerExtended(indexTip, indexPip);
  const middle = isFingerExtended(middleTip, middlePip);
  const ring = isFingerExtended(ringTip, ringPip);
  const pinky = isFingerExtended(pinkyTip, pinkyPip);

  // ✋ STOP → all fingers open
  if (index && middle && ring && pinky) return "STOP";

  // 👍 YES → thumb up, others down
  if (
    thumbTip.y < landmarks[3].y &&
    !index && !middle && !ring && !pinky
  ) {
    return "YES";
  }

  // ✊ NO → fist
  if (!index && !middle && !ring && !pinky) return "NO";

  return "Unknown";
}

// ================== STABILITY + SPEECH CONTROL ==================
function handleGesture(newGesture) {
  if (newGesture === currentGesture) {
    gestureCounter++;
  } else {
    currentGesture = newGesture;
    gestureCounter = 1;
  }

  // Stable gesture confirmed
  if (
    gestureCounter === STABLE_FRAMES &&
    newGesture !== lastStableGesture
  ) {
    lastStableGesture = newGesture;
    gestureText.textContent = `Detected Sign: ${newGesture}`;

    // 🔊 Speak only if gesture changed
    if (newGesture !== "Unknown" && newGesture !== lastSpokenGesture) {
      speak(newGesture);
      lastSpokenGesture = newGesture;
    }
  }
}

// ================== MEDIAPIPE HANDS ==================
const hands = new Hands({
  locateFile: (file) =>
    `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
});

hands.setOptions({
  maxNumHands: 1,
  modelComplexity: 1,
  minDetectionConfidence: 0.7,
  minTrackingConfidence: 0.7,
});

hands.onResults((results) => {
  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
  canvasCtx.drawImage(
    results.image,
    0,
    0,
    canvasElement.width,
    canvasElement.height
  );

  if (results.multiHandLandmarks) {
    for (const landmarks of results.multiHandLandmarks) {
      drawConnectors(canvasCtx, landmarks, HAND_CONNECTIONS, {
        color: "#00FF00",
        lineWidth: 2,
      });
      drawLandmarks(canvasCtx, landmarks, {
        color: "#FF0000",
        lineWidth: 1,
      });

      const gesture = detectGesture(landmarks);
      handleGesture(gesture);
    }
  }
});

// ================== CAMERA ==================
const camera = new Camera(videoElement, {
  onFrame: async () => {
    await hands.send({ image: videoElement });
  },
  width: 640,
  height: 480,
});

camera.start();
