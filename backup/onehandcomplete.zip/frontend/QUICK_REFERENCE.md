# 🚀 Quick Reference: Current Gesture Set

## ✅ Working Gestures (8 Total)

### Numbers (6)
- **NUMBER_0** - Tight fist (all fingers curled)
- **NUMBER_1** - Index finger only
- **NUMBER_2** - Peace sign (index + middle, thumb curled)
- **NUMBER_3** - Three fingers (index + middle + ring)
- **NUMBER_4** - Four fingers (all except thumb)
- **NUMBER_5** - Open palm (all 5 extended)

### Actions (2)
- **THUMBS_UP** - Thumb pointing up, all fingers curled
- **THUMBS_DOWN** - Thumb pointing down, all fingers curled
- **OK** - Thumb + index circle, other fingers extended
- **PEACE** - Index + middle extended, thumb OUT (extended)

## 🎮 How to Make Each Gesture

| Gesture | Position | Fingers |
|---------|----------|---------|
| **NUMBER_0** | Fist | All curled, thumb in |
| **NUMBER_1** | One finger up | Index only extended |
| **NUMBER_2** | Peace sign | Index + middle, thumb curled |
| **NUMBER_3** | Three fingers | Index + middle + ring |
| **NUMBER_4** | Four fingers | All but thumb |
| **NUMBER_5** | Open palm | All 5 extended |
| **THUMBS_UP** | Fist, thumb up | Thumb up, all fingers curled |
| **THUMBS_DOWN** | Fist, thumb down | Thumb down, all fingers curled |
| **OK** | Circle with fingers | Thumb + index touching, others up |
| **PEACE** | Peace sign | Index + middle, **THUMB OUT** |

## ⚠️ Key Differences

### NUMBER_2 vs PEACE
- **NUMBER_2**: INDEX + MIDDLE, THUMB CURLED
- **PEACE**: INDEX + MIDDLE, THUMB EXTENDED ← Thumb is the key difference!

### NUMBER_0 vs THUMBS_DOWN
- **NUMBER_0**: All fingers curled, thumb curled/neutral
- **THUMBS_DOWN**: All fingers curled, thumb pointing downward

## 🔍 Detection Priority

1. **THUMBS_DOWN** - Checked first (before NUMBER_0)
2. **Numbers (0-5)** - Most specific patterns
3. **THUMBS_UP** - Thumb up, all curled
4. **OK** - Circle gesture
5. **PEACE** - Peace sign with thumb out

## 🧪 Testing Checklist

- [ ] NUMBER_0 - Fist
- [ ] NUMBER_1 - One finger
- [ ] NUMBER_2 - Peace sign
- [ ] NUMBER_3 - Three fingers
- [ ] NUMBER_4 - Four fingers
- [ ] NUMBER_5 - Open palm
- [ ] THUMBS_UP - Thumb up
- [ ] THUMBS_DOWN - Thumb down
- [ ] OK - Circle gesture
- [ ] PEACE - Peace sign with thumb

## 🆘 Quick Help

**Gesture not detecting?**
- Check console (F12) for errors
- Hold pose steady for ~100ms (3 frames)
- Ensure good lighting on hands
- Make sure fingers match exact positions

**NUMBER_0 and THUMBS_DOWN mixing?**
- THUMBS_DOWN is now checked first
- Make sure thumb clearly points downward for THUMBS_DOWN
- For NUMBER_0, keep thumb more neutral/curled

**Performance issues?**
- Reduce video resolution if needed
- Close other browser tabs
- Check browser console for errors
